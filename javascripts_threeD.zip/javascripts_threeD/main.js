import './style.css';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';


const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer({
  canvas: document.querySelector('#bg'),
});

renderer.setPixelRatio(window.devicePixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
camera.position.setZ(30);
camera.position.setX(-3);

renderer.render(scene, camera);


const pointLight = new THREE.PointLight(0xffffff);
pointLight.position.set(5, 5, 5);

const ambientLight = new THREE.AmbientLight(0xffffff);
scene.add(pointLight, ambientLight);



// Background
const spaceTexture = new THREE.TextureLoader().load('ant2.jpg');
scene.background = spaceTexture;


const red_antTexture = new THREE.TextureLoader().load('red_ant.png');
const normalTexture = new THREE.TextureLoader().load('red_ant.png');

const red_antTexture1 = new THREE.TextureLoader().load('green_ant.jpg');
const normalTexture1 = new THREE.TextureLoader().load('green_ant.jpg');


const red_ant = new THREE.Mesh(
  new THREE.SphereGeometry(3, 32, 32),
  new THREE.MeshStandardMaterial({
    map: red_antTexture,
    normalMap: normalTexture,
  })
);
const red_ant1 = new THREE.Mesh(
  new THREE.SphereGeometry(3, 32, 32),
  new THREE.MeshStandardMaterial({
    map: red_antTexture1,
    normalMap: normalTexture1,
  })
);


scene.add(red_ant);
scene.add(red_ant1);

red_ant.position.z = 30;
red_ant.position.setX(-10);


red_ant1.position.z = 20;
red_ant1.position.setX(-10);


// Scroll Animation

function moveCamera() {
  const t = document.body.getBoundingClientRect().top;
  red_ant.rotation.x += 0.05;
  red_ant.rotation.y += 0.075;
  red_ant.rotation.z += 0.05;
  red_ant1.rotation.x += 0.05;
  red_ant1.rotation.y += 0.075;
  red_ant1.rotation.z += 0.05;


 
  camera.position.z = t * -0.01;
  camera.position.x = t * -0.0002;
  camera.rotation.y = t * -0.0002;
}

document.body.onscroll = moveCamera;
moveCamera();

// Animation Loop

function animate() {
  requestAnimationFrame(animate);


  red_ant.rotation.x += 0.4;
  red_ant1.rotation.x += 0.2;


  // controls.update();

  renderer.render(scene, camera);
}

animate();
